<div class="mt-6">
    {{ $slot }}
</div>
