# Laravel Test Project From Scratch (interview task)

## to run my project please follow the following steps
cp .env.example .env
```

Then create the DB.

```
php artisan db
create database blog
```

And run the initial migrations and seeders.

```
php artisan migrate --seed
```

## i'm looking forward to work with you. Thankyou!